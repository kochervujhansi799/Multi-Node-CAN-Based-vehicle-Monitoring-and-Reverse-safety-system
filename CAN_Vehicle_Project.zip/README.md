# Multi-Node CAN Vehicle Monitoring & Reverse Safety System

Three independent LPC2129 boards talk over one CAN bus:

| Node               | Reads              | Sends (CAN)         | Receives (CAN)     | Shows / does            |
|---------------------|--------------------|----------------------|---------------------|--------------------------|
| Main Node            | DS18B20 temp, SW1/SW2, MODE switch | ID 0x01 (indicator cmd) | ID 0x02 (obstacle flag) | LCD: temp, mode, indicator, alert; drives buzzer |
| Indicator Node        | ID 0x01 from CAN   | -                     | ID 0x01              | 8 LEDs scroll left/right |
| Reverse Alert Node    | HC-SR04 distance   | ID 0x02 (obstacle flag) | -                    | -                          |

## 1. Folder layout

```
common/            <- shared code, copy into every Keil project
  types.h  defines.h
  delay.c/.h        Timer1-based microsecond delay
  lcd.c/.h          your 8-bit HD44780 driver (unchanged)
  ds18b20.c/.h      1-Wire temperature sensor driver
  ultrasonic.c/.h   HC-SR04 driver (Timer0 stopwatch)
  can.c/.h          on-chip CAN1 driver (non-blocking, self-timing-out)
  eint.c/.h         SW1 / SW2 / MODE switch interrupts (Main Node only)

Main_Node/main.c
Indicator_Node/main.c
Reverse_Alert_Node/main.c
```

Each node is its own Keil project. Add `main.c` from that node's folder
plus every file in `common/` (except you don't need `eint.c/h` in the
Indicator or Reverse Alert nodes, and you don't need `lcd.c/h` or
`ds18b20.c/h` there either -- see the per-node list below).

| File              | Main Node | Indicator Node | Reverse Alert Node |
|--------------------|:---------:|:---------------:|:--------------------:|
| types.h, defines.h |   yes     |   yes (types.h only) | yes (types.h only) |
| delay.c/.h         |   yes     |   yes            | yes                  |
| lcd.c/.h           |   yes     |   no             | no                    |
| ds18b20.c/.h       |   yes     |   no             | no                    |
| ultrasonic.c/.h    |   no      |   no             | yes                   |
| can.c/.h           |   yes     |   yes            | yes                   |
| eint.c/.h          |   yes     |   no             | no                    |

## 2. Pin map (edit the `#define`s in the headers if your board differs)

| Signal            | Pin    | Used by            |
|--------------------|--------|----------------------|
| LCD D0-D7           | P0.8-P0.15 | Main Node          |
| LCD RS              | P0.16  | Main Node             |
| LCD RW              | P0.17  | Main Node             |
| LCD EN               | P0.18  | Main Node             |
| DS18B20 DQ           | P0.19  | Main Node (4.7k pull-up to 3.3V, VDD to 3.3V) |
| HC-SR04 TRIG          | P0.21  | Reverse Alert Node |
| HC-SR04 ECHO (via divider) | P0.22 | Reverse Alert Node |
| CAN1 TD1              | dedicated pin | all nodes    |
| CAN1 RD1               | P0.25  | all nodes            |
| SW1 (left)              | P0.1 (EINT0) | Main Node       |
| SW2 (right)              | P0.3 (EINT1) | Main Node       |
| MODE switch               | P0.7 (EINT2) | Main Node       |
| Buzzer / alert LED          | P0.0    | Main Node          |
| 8 indicator LEDs             | P1.16 - P1.23 | Indicator Node |

## 3. CAN bus wiring

Each board: LPC2129 TD1/RD1 -> MCP2551 -> CANH/CANL.
- 120 ohm resistor between CANH and CANL at **each physical end** of
  the bus (not on every board -- only the two ends).
- Common GND between all boards.
- Same bit rate everywhere: 125 kbps (set in `can.h`).

## 4. Why a disconnected node cannot freeze the others

- **CAN1_Tx()** (in `can.c`) waits for the buffer and for the ACK, but
  only inside a bounded software loop (`CAN_TX_TIMEOUT`). If nobody
  acknowledges the frame it gives up and returns an error code -- it
  never loops forever.
- **CAN1_Rx()** never waits by itself. Every node calls
  `CAN1_RxReady()` first, and only calls `CAN1_Rx()` when that returns
  1. If no message ever arrives, the node simply keeps running its own
  sensor/LED/LCD loop.
- Each node also tracks how long it has been since it last heard from
  the node it depends on (`missedReverse` in the Main Node, `missed`
  in the Indicator Node). After a short timeout it assumes the other
  node is gone and fails safe (buzzer off, LEDs off, "No Signal" on
  the LCD) instead of showing stale or frozen data.
- The Reverse Alert Node sends its status on a fixed timer regardless
  of whether the Main Node answers, so it never depends on the Main
  Node being present.

## 5. Bring-up order (matches the 8-day plan)

1. Build and flash the **Main Node** alone first (LCD + temperature +
   switches). Confirm the LCD shows a real temperature and the
   indicator letter (L/R/-) changes with SW1/SW2, and FWD/REV toggles
   with MODE.
2. Build and flash the **Indicator Node** alone. LEDs should stay off
   (no CAN traffic yet).
3. Connect Main Node and Indicator Node on the same CAN bus with
   termination resistors. Press SW1/SW2 on the Main Node; the LEDs on
   the Indicator Node should scroll.
4. Build and flash the **Reverse Alert Node** alone, confirm distance
   readings are correct (as you already tested).
5. Connect all three nodes. Switch the Main Node to REVERSE mode and
   bring an object close to the ultrasonic sensor; the Main Node's
   buzzer/LED and LCD should react.
6. Unplug each node one at a time while the system is running, and
   confirm the other two keep working (this is the disconnection
   requirement).

## 6. Tuning

- `THRESHOLD_CM` in `Reverse_Alert_Node/main.c` -- obstacle distance,
  default 30 cm.
- `REVERSE_LINK_TIMEOUT` in `Main_Node/main.c` -- how many ~1s loop
  passes without a reverse-alert message before showing "No Signal".
- `LINK_TIMEOUT` in `Indicator_Node/main.c` -- same idea, in ~150ms
  steps.
- `SCROLL_STEP_MS` in `Indicator_Node/main.c` -- LED scroll speed.
